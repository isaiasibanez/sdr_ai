function [errors] = ...
    redRKEFerrors(redRKEFtrain,redRKEFtest,Ytrain,Ytest,d,scaleKEF,classifiers,Kfold_int,tol,costSVM,hiddensize)
% Performance train/test with internal selection of parameters.
%
%   Inputs:
%       - redRKEFtrain, redRKEFtest: reduced data via RKEF.
%       - Ytrain, Ytest: classes.
%       - d: dimension used for reduction (step 2).
%       - denv: dimension used for reduction.
%       - scaleKEF: bandwith for gaussian kernel in RKEF method.
%       - classifiers: vectors of classifiers (LDA, QDA, LSVM and/or MLP).
%       - Kfold_int: for internal selection of parameters via 'param_sel'.
%       - tol: tolerance to prevent overfitting.
%       - costSVM = cost for LSVM classifier.
%       - hiddensize = number of neurons in hidden layer of MLP.
%         
%   Outputs: Errors for different configurations.


nclass = length(unique(Ytrain));
nd = length(d);

errors = cell(1,length(classifiers));

% Classification:
count = 1;
for d2 = 1:nd
    aux = 1;
    
    % LDA:
    if any(classifiers == 'LDA')
        % (a) parameter selection: scaleKEF
        [~,~,sopt] = param_sel_RKEF('LDA',Kfold_int,redRKEFtrain(d2,:),Ytrain,scaleKEF,tol);
        % (b) test error
        modeloLDA = fitcdiscr(redRKEFtrain{d2,sopt},Ytrain);
        Yfit = predict(modeloLDA,redRKEFtest{d2,sopt});
        error = mean(Yfit~=Ytest);
        errors{aux}(count,:) = [d(d2),error];
        fprintf('Reduction RKEF to d = %d (%d/%d) | Error LDA: %d \n',...
            d(d2),d2,nd,error)
        aux = aux+1;
    end

    % QDA:
    if any(classifiers == 'QDA')
        % (a) parameter selection: scaleKEF
        [~,~,sopt] = param_sel_RKEF('QDA',Kfold_int,redRKEFtrain(d2,:),Ytrain,scaleKEF,tol); 
        % (b) test error
        try
            modeloQDA = fitcdiscr(redRKEFtrain{d2,sopt},Ytrain,'DiscrimType','quadratic');
        catch
            modeloQDA = fitcdiscr(redRKEFtrain{d2,sopt},Ytrain,'DiscrimType','pseudoquadratic');
        end
        Yfit = predict(modeloQDA,redRKEFtest{d2,sopt});
        error = mean(Yfit~=Ytest);
        errors{aux}(count,:) = [d(d2),error];
        fprintf('Reduction RKEF to d = %d (%d/%d) | Error QDA: %d \n',...
            d(d2),d2,nd,error)
        aux = aux+1;
    end


    % LSVM:
    if any(classifiers == 'LSVM')
        % (a) parameter selection: scaleKEF,costSVM
        [~,~,opt] = param_sel_RKEF('LSVM',Kfold_int,redRKEFtrain(d2,:),Ytrain,scaleKEF,tol,costSVM); 
        sopt = opt(1); copt = opt(2);
        % (b) test error
        t = templateSVM('Standardize',true,'KernelFunction','linear',...
            'BoxConstraint',costSVM(copt));
        modeloSVML = fitcecoc(redRKEFtrain{d2,sopt},Ytrain,'Learners',t,'Verbose',0);
        Yfit = predict(modeloSVML,redRKEFtest{d2,sopt});
        error = mean(Yfit~=Ytest);
        errors{aux}(count,:) = [d(d2),error];
        fprintf('Reduction RKEF to d = %d (%d/%d) | Error LSVM: %d \n',...
            d(d2),d2,nd,error)
        aux = aux+1;
    end


    % MLP:
    if any(classifiers == 'MLP')
        % (a) parameter selection: scaleKEF,hiddensize
        [~,~,opt] = param_sel_RKEF('MLP',Kfold_int,redRKEFtrain(d2,:),Ytrain,scaleKEF,tol,hiddensize); 
        sopt = opt(1); hopt = opt(2);
        % (b) test error
        Ytrainnew = zeros(length(Ytrain),nclass);
        for i=1:length(Ytrain)
            class = Ytrain(i);
            Ytrainnew(i,class) = 1;
        end
        modeloMLP = patternnet(hiddensize(hopt));
        modeloMLP.trainParam.showWindow = 0;
        modeloMLP = train(modeloMLP,redRKEFtrain{d2,sopt}',Ytrainnew');
        Yfit = modeloMLP(redRKEFtest{d2,sopt}');
        Yfit = vec2ind(Yfit);
        error = mean(Yfit~=Ytest');
        errors{aux}(count,:) = [d(d2),error];
        fprintf('Reduction RKEF to d = %d (%d/%d) | Error MLP: %d \n',...
            d(d2),d2,nd,error)
    end
count = count+1;
end
end