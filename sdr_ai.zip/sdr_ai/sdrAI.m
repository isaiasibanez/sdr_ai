function [redAItrain,redAItest] = sdrAI(Xtrain,Wtrain,Ytrain,Xtest,d,denv,scaleKEF,Wtype,comb)
% Reduction with additional information via generalized two-step method
% involving kernel-methods. This function implements RKEF-AI by default. 
% Only if you want to implement RKEF-AI(COIR), include the inputs 'Wtype'
% and 'comb'.
%
%   Inputs:
%       - Xtrain, Wtrain, Ytrain: train data.
%       - Xtest: test data to be reduced.
%       - d: dimension required for reduction (step 2).
%       - denv: dimension required for reduction in step 1.
%       - scaleKEF: bandwith for gaussian kernel in RKEF method ('auto' by
%       default)
%       - Wtype: specify whether W is discrete ('disc') or continuous
%       ('cont')
%       - comb: weight/s for obtaining kernel matrix Kyw in COIR.
%         
%   Outputs: Reduction of Xtest and Xtrain.

if denv < d
error('denv must be less than d')
end

if nargin < 7
    scaleKEF = 'auto';
end

% Reductions with additional information:

if nargin<8
    % Paso 1 (RKEF):
    [redtrain1,redtest1,~] = RKEF(YWtrain,Xtrain,dim_int(d1),'auto',Xtest);
    redtrain1 = real(redtrain1); redtest1 = real(redtest1);
    % Paso 2 (RKEF):
    [redtrain2,redtest2,~] = RKEF(Ytrain,redtrain1,dim(d2),scaleKEF{s},redtest1);
    redAItrain{d2,d1,s} = real(redtrain2);
    redAItest{d2,d1,s} = real(redtest2);
else
    % Paso 1 (COIR):
    aux = dist(Xtrain).^2;
    kerparx = sqrt(median(aux(:)));
    Kx = kernel2('rbf',kerparx,Xtrain,Xtrain);
    Kyw = get_Kyw(Ytrain,Wtrain,'disc',Wtype,comb(c));
    Kt = kernel2('rbf',kerparx,Xtest,Xtrain);
    groupIdx = ones(size(Ytrain));
    [~,~,redtrain1,redtest1] = dica(Kx,Kyw,Kt,groupIdx,.10,.05,denv(d1));
    redtrain1 = real(redtrain1'); redtest1 = real(redtest1');
    % Paso 2 (RKEF):
    [redtrain2,redtest2,~] = RKEF(Ytrain,redtrain1,dim(d2),scaleKEF{s},redtest1);
    redAItrain{d2,d1,s,c} = real(redtrain2);
    redAItest{d2,d1,s,c} = real(redtest2);
end

end
