function [fv,beta,st,errormin] = cise_cv(Yfull,Xfull,dim,pw,nfolds,method)
% This is the main function that achives coordinate-independent sparse estimation using
% either SIR or PFC for calculating M and N matrices. See references for details.
%    USAGE:
%  - outputs:
%    fv: the value of the objective function at the estimator
%    beta:  the estimator of the central subspace based on BIC criterion.
%    st: a vector with either 0 or 1 element to indicate which variable is
%    to be selected by CISE.

%  - inputs:
%    y: response vector.
%    x: predictors matrix.
%    di: the dimension of the central subspace
%    pw: the range of the penalty parameter of \lambda is from 0 to pw. 
%    method: model to calculate M and N matrices. So far, only 'PFC' or 'SIR' is accepted.
%
%
global p; % the number of predictor
global d; % the dimension of the central subspace
global n;
global M;
global N;


% if ~isinZ(Yfull)
%     Yfull = slices(Yfull,6);
%     disp('slicing respose');
% end
% Y = grp2idx(Yfull);
% h = max(Y);
p = cols(Xfull);
d = dim;

% CV partitions
N = length(Yfull);
div = floor(N/nfolds);
newidx = shuffle(1:N); newidx=newidx(:);
for k=1:nfolds,
    idx = newidx((k-1)*div+1:k*div);
    Xcv{k} = Xfull(idx,:); 
    Ycv{k} = Yfull(idx);
end
Xcv{nfolds} = Xfull((nfolds-1)*div+1:end,:);
Ycv{nfolds} = Yfull((nfolds-1)*div+1:end);


for cv=1:nfolds,
    disp(cv)
    Ytest = Ycv{cv};
    Xtest = Xcv{cv};
    X = []; Y = [];
    parfor k=1:nfolds,
        if k~=cv,
            X = [X;Xcv{k}];
            Y = [Y;Ycv{k}];
        end
    end
    
    if strcmpi(method,'SIR')
        [M,N]=SIR(Y,X,nslice);
    elseif strcmpi(method,'PFC')
        [M,N] = PFC(Y,X);
    elseif strcmpi(method,'AIDA')
        [M,N] = MN4aida(Y,X);
    elseif strcmpi(method,'EPFC')
        [M,N] = MN4epfc(Y,X);
    else
        error('Unknown method. Check syntax');
        exit;
    end

    %###############################################
    pw = max(pw);
    nin = pw*100+1;
    for i=1:nin
        [f,beta] = get_penprj(i/100-0.01);
        newX = [ones(size(Ytest)) Xtest*beta];
        Yhat = newX*regress(Ytest,newX);
        stop(i) = norm(Yhat-Ytest);
    end
    [f,ind] = min(stop);
    lap = ind/100-0.01;
    for k = 1:19
        [f,newbeta] = get_penprj(lap-0.01+k/1000);
        newX = [ones(size(Ytest)) Xtest*newbeta];
        Yhat = newX*regress(Ytest,newX);
        dstop(i) = norm(Yhat-Ytest);
    end
    [f,dind] = min(dstop);
    dlap = lap-0.01+dind/1000;
    [fv, beta, st] = get_penprj(dlap);  
    newX = [ones(size(Ytest)) Xtest*beta];
    Yhat = newX*regress(Ytest,newX);
    errorcv(cv) = norm(Yhat-Ytest);
%     for i=1:length(pw),
%         lambda = pw(i);
%         [f,beta] = get_penprj(lambda);
%         newX = [ones(size(Ytest)) Xtest*beta];
%         Yhat = newX*regress(Ytest,newX);
%         errorcv(i,cv) = norm(Yhat-Ytest);
% %         labels = classify(Xtest*beta,X*beta,Y,'quadratic','empirical');
% %         errorcv(i,cv) = length(find(labels~=Ytest))/length(Ytest);
%     end
end
% meanerror = mean(errorcv,2);
meanerror = mean(errorcv);
[errormin,ind] = min(meanerror);
[fv, beta, st] = get_penprj(ind);
