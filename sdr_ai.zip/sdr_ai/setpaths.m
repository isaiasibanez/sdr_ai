function setpaths
    % Add all subfolders to the search path
    addpath(genpath(pwd));
end