function [V,D,X,Xt] = dica(Kx, Ky, Kt, groupIdx, lambda, epsilon, M)
% dica - supervised domain-invariant component analysis
%
% Synopsis
%   [V,D,X,Xt] = dica(Kx, Ky, Kt, groupIdx, lambda, epsilon, M)
%
% Description
%   Domain-invariant component analysis (DICA) finds a low dimensional
%   subspace of data points from several distributions so as to minimize 
%   the variance among the distributions of projected data points. It also
%   takes into account the affinity in the output space.
% 
%
% Inputs ([]s are optional)
%   (matrix) Kx         NxN kernel matrix between data points
%   (matrix) Ky         NxN kernel matrix between outputs
%   (matrix) Kt         NtxN kernel matrix between test samples and
%                           training samples
%   (vector) groupIdx   Nx1 vector of group membership of data points
%   (scalar) lambda     The regularization parameter (input)
%   (scalar) epsilon    The regularization parameter (output)
%   (scalar) M          The dimensionality of subspace (M < N)
%
% Outputs ([]s are optional)
%   (matrix) V          Nxdim matrix in which each column is the
%                       eigenvector
%   (matrix) D          MxM diagonal matrix in which the diagonal elements
%                       are eigenvalues associated with the eigenvectors in
%                       the matrix V
%   (matrix) X          MxN matrix in which each column is the projection
%                       of original data point onto the subspace spanned by
%                       the eigenvectors in the matrix V
%   (matrix) Xt         MxNt matrix in which each column is the projection
%                       of test data point onto the subspace spanned by
%                       the eigenvectors in the matrix V
%
% Examples
%   <Example Code>
%
% See also
%   <See Also Function Name>
%
% Requirements
%   eigs (MATLAB)

% References
%   K. Muandet, D.Balduzzi,and B.Sch?lkopf, Domain Generalization via 
%   Invariant Feature Representation. The 30th International Conference on 
%   Machine Learning (ICML 2013), pages 10?18, Atlanta, Georgia.
%
% Authors
%   Krikamol Muandet <krikamol@tuebingen.mpg.de>
%
% License
%   The code can only be used for academic and research purposes.
%
% Changes
%   25/04/2012  First Edition
%   ...

if size(Kx,1) ~= size(Kx,2) || size(Ky,1) ~= size(Ky,2)
    error('Kx and Ky must be a symmetric matrix.');
end

N = size(Kx,1);                     % number of data points
Nt = size(Kt,1);
uniqueGroupIdx = unique(groupIdx);  % unique group indexes
G = length(uniqueGroupIdx);         % number of groups
NG = hist(groupIdx,uniqueGroupIdx); % number of data points in each group

H  = eye(N) - ones(N)./N;            % centering matrix

% construct the L matrix
L = zeros(N,N);
for i=1:N
    for j=1:N
        if groupIdx(i) == groupIdx(j)
            groupSize = NG(uniqueGroupIdx == groupIdx(i));
            L(i,j) = 1/(G*groupSize*groupSize) - 1/(G*G*groupSize*groupSize);
        else
            groupSize_i = NG(uniqueGroupIdx == groupIdx(i));
            groupSize_j = NG(uniqueGroupIdx == groupIdx(j));
            L(i,j) = - 1/(G*G*groupSize_i*groupSize_j);
        end
    end
end

% perform eigendecomposition (this step can be improved for efficiency)
Ky = H*Ky*H;
Kx = H*Kx*H;

A = (Kx*L*Kx + Kx + lambda.*eye(N)) \ (Ky*((Ky + N.*epsilon.*eye(N)) \ Kx*Kx));

[V,D] = eigs(A,[],M);
Evals = real(diag(D));
for i=1:M
  V(:,i) = V(:,i)/(sqrt(Evals(i)));
end

% projection of data points
X = V'*Kx;

if ~isempty(Kt)
    Ht = eye(Nt) - ones(Nt)./Nt;
    Kt = Ht*Kt*H;
    Xt  = V'*Kt';    
else
    Xt = [];
end

end
