%%%This is the script to reproduce figure 2a from the paper by
%%% R. D. Cook and L. Forzani: "Likelihood-based Sufficient Dimension
%%% Reduction". To appear in JASA

%
% Brief Description
% 
% The script compares LAD and F2M methods SIR, SAVE and DR by computing the angle 
% between them and the known central subspace. The regression model for the response 
% is Y = 4*X1/a + err. Figure shows the average angle for different values of parameter 
% 'a' in the regression model. See the paper for details.
% =========================================================================


clear all; 
tic
%setpaths;
ncols = 10;
nrep = 200;

%%  
% figure 2a
h=5;
u=1;
alp = zeros(ncols,1);
alp(1,1) = 1;
nn = 75:25:500;
angulos = zeros(nrep,length(nn),7);
a = 2;
for n=1:length(nn)
  disp(strcat('n =',int2str(nn(n))));
  nrows = nn(n);
  for j=1:nrep
     X=normrnd(0,1,nrows,ncols);

     yr=4*(X*alp(:,1)) ;
%      y=normrnd(yr,1);
    y= yr + a*randn(nrows,1);    

    [WX, W]=ldr(y,X,'lad','cont',u,'nslices',h);
    angulos(j,n,1)=subspace(W,alp)*180/pi;

    [WX, W]=SIR(y,X,'cont',u,'nslices',h);
    angulos(j,n,2)=subspace(W,alp)*180/pi;
    
    [WX, W]=SAVE(y,X,'cont',u,'nslices',h);
    angulos(j,n,3)=subspace(W,alp)*180/pi;

    [WX, W]=DR(y,X,'cont',u,'nslices',h);    
    angulos(j,n,4)=subspace(W,alp)*180/pi;

    W = aida(y,X,u,'cont');
    angulos(j,n,5)=subspace(W,alp)*180/pi;
    
    %% DCOV
%     [eta,idx] = fedcov(X,y,u,2);
%     angulos(j,n,6) = subspace(eta,alp)*180/pi;

%     %% DCOV
    [eta,idx] = fedcov(X,y,u,2,'projection');
    angulos(j,n,6) = subspace(eta,alp)*180/pi;

    %% gKDR
      [eta,~] = KernelDeriv(X,y,u,MedianDist(X),MedianDist(y),.0001);
%      eta = my_gKDRcv(X,y,u);
     angulos(j,n,7) = subspace(eta,alp)*180/pi;


  end
end

toc
%%
%meanang = zeros(amax,4);
meanang = mean(angulos(:,:,1:7),1);
sd = std(angulos(:,:,1:7),1); 

figure;
set(gca,'LineWidth',2.5);
plot(nn,squeeze(meanang));
%label
% title('Y=4X_1 + \sigma\epsilon');
xlabel('sample size');
ylabel('ANGLE');
legend('LAD','SIR','SAVE','DR','AIDA','SeqFESIC','Location','Best');

%%
hold on;
plot(nn,squeeze(meanang)+squeeze(sd));
plot(nn,squeeze(meanang)-squeeze(sd));
%%
save('dcov_case1_efficiency.mat')