function [errors] = ...
    redAIerrors(redAItrain,redAItest,Ytrain,Ytest,d,denv,scaleKEF,comb,classifiers,Kfold_int,tol,costSVM,hiddensize)
% Performance train/test with internal selection of parameters.
%
%   Inputs:
%       - redAItrain, redAItest: reduced train data.
%       - Ytrain, Ytest: classes.
%       - d: dimension used for reduction (step 2).
%       - denv: dimension used for reduction in step 1.
%       - scaleKEF: bandwith for gaussian kernel in RKEF method.
%       - comb: weight/s for obtaining kernel matrix Kyw in COIR.
%       - classifiers: vectors of classifiers (LDA, QDA, LSVM and/or MLP).
%       - Kfold_int: for internal selection of parameters via 'param_sel_AI'.
%       - tol: tolerance to prevent overfitting.
%       - costSVM = cost for LSVM classifier.
%       - hiddensize = number of neurons in hidden layer of MLP.
%         
%   Outputs: Errors for different configurations.


nclass = length(unique(Ytrain));
nd = length(d);
ndenv = length(denv);

total = 0;
for d2 = 1:nd
    for d1 = 1:ndenv
        if denv(d1)<=d(d2)
            continue
        end
        redtrain = redAItrain(d2,d1,:,:);
        if sum([redtrain{:}])== 0
            continue
        end
        total = total + 1;
    end
end

errors = cell(1,length(classifiers));

% Classification:
count = 1;
for d2 = 1:nd
    for d1 = 1:ndenv
        
        if denv(d1)<=d(d2)
            continue
        end
        
        redtrain = redAItrain(d2,d1,:,:);
        if sum(sum([redtrain{:}]))== 0
            continue
        end
        
        aux = 1;
        
        % LDA:
        if any(classifiers == 'LDA')
            % (a) parameter selection: scaleKEF,comb
            [~,~,opt] = param_sel_AI('LDA',Kfold_int,redAItrain(d2,d1,:,:),Ytrain,scaleKEF,comb,tol);
            sopt = opt(1); comb_opt = opt(2);
            % (b) test error
            modeloLDA = fitcdiscr(redAItrain{d2,d1,sopt,comb_opt},Ytrain);
            Yfit = predict(modeloLDA,redAItest{d2,d1,sopt,comb_opt});
            error = mean(Yfit~=Ytest);
            errors{aux}(count,:) = [d(d2),denv(d1),error];
            fprintf('Reduction to d = %d (%d/%d), denv = %d (%d/%d) | Error LDA: %d \n',...
                d(d2),d2,nd,denv(d1),d1,ndenv,error)
            aux = aux+1;
        end


        % QDA:
        if any(classifiers == 'QDA')
            % (a) parameter selection: scaleKEF
            [~,~,opt] = param_sel_AI('QDA',Kfold_int,redAItrain(d2,d1,:,:),Ytrain,scaleKEF,comb,tol);
            sopt = opt(1); comb_opt = opt(2);
            % (b) test error
            try
                modeloQDA = fitcdiscr(redAItrain{d2,d1,sopt,comb_opt},Ytrain,'DiscrimType','quadratic');
            catch
                modeloQDA = fitcdiscr(redAItrain{d2,d1,sopt,comb_opt},Ytrain,'DiscrimType','pseudoquadratic');
            end
            Yfit = predict(modeloQDA,redAItest{d2,d1,sopt,comb_opt});
            error = mean(Yfit~=Ytest);
            errors{aux}(count,:) = [d(d2),d(d1),error];
            fprintf('Reduction to d = %d (%d/%d), denv = %d (%d/%d) | Error QDA: %d \n',...
                d(d2),d2,nd,denv(d1),d1,ndenv,error)
            aux = aux+1;
        end


        % LSVM:
        if any(classifiers == 'LSVM')
            % (a) parameter selection: scaleKEF,costSVM
            [~,~,opt] = param_sel_AI('LSVM',Kfold_int,redAItrain(d2,d1,:,:),Ytrain,scaleKEF,comb,tol,costSVM); 
            sopt = opt(1); comb_opt = opt(2); copt = opt(3);
            % (b) test error
            t = templateSVM('Standardize',true,'KernelFunction','linear',...
                'BoxConstraint',costSVM(copt));
            modeloSVML = fitcecoc(redAItrain{d2,d1,sopt,comb_opt},Ytrain,'Learners',t,'Verbose',0);
            Yfit = predict(modeloSVML,redAItest{d2,d1,sopt,comb_opt});
            error = mean(Yfit~=Ytest);
            errors{aux}(count,:) = [d(d2),denv(d1),error];
            fprintf('Reduction to d = %d (%d/%d), denv = %d (%d/%d) | Error LSVM: %d \n',...
                d(d2),d2,nd,denv(d1),d1,ndenv,error)
            aux = aux+1;
        end


        % MLP:
        if any(classifiers == 'MLP')
            % (a) parameter selection: scaleKEF,hiddensize
            [~,~,opt] = param_sel_AI('MLP',Kfold_int,redAItrain(d2,d1,:,:),Ytrain,scaleKEF,comb,tol,hiddensize); 
            sopt = opt(1); comb_opt = opt(2); hopt = opt(3);
            % (b) test error
            Ytrainnew = zeros(length(Ytrain),nclass);
            for i=1:length(Ytrain)
                class = Ytrain(i);
                Ytrainnew(i,class) = 1;
            end
            modeloMLP = patternnet(hiddensize(hopt));
            modeloMLP.trainParam.showWindow = 0;
            modeloMLP = train(modeloMLP,redAItrain{d2,d1,sopt,comb_opt}',Ytrainnew');
            Yfit = modeloMLP(redAItest{d2,d1,sopt,comb_opt}');
            Yfit = vec2ind(Yfit);
            error = mean(Yfit~=Ytest');
            errors{aux}(count,:) = [d(d2),denv(d1),error];
            fprintf('Reduction to dim = %d (%d/%d), denv = %d (%d/%d) | Error MLP: %d \n',...
                d(d2),d2,nd,denv(d1),d1,ndenv,error)
        end
        count = count+1;
    end
end
end