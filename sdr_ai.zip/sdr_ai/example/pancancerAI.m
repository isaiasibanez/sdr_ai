%% DATA LOADING
% Data used is from International Cancer Genome Consortium (ICGC), but it
% is also available in a shared folder:
% https://drive.google.com/drive/folders/1JeULeRrNv3sOc_-XGVfl-Qc-rvlcspp5?usp=sharing

Xtrain = csvread('xtr.csv',1,1);
Xtest = csvread('xte.csv',1,1);
[~,p] = size(Xtrain);                               % dimension of X


Ytrain = csvread('ytr_type.csv',1,1);
Ytest = csvread('yte_type.csv',1,1);
r = length(unique(Ytrain));                         % number of classes

Wtrain = csvread('xtr_ae.csv',1,1);
Wtest = csvread('xte_ae.csv',1,1);
[~,k] = size(Wtrain);                               % dimension of W

% Initial random reduction of X:
rng(500)
P = randn(p,1000); 
Xtrain = Xtrain*P;
Xtest = Xtest*P;
[~,p] = size(Xtrain);


% Recommended: Save data at this point.
save('./save')


%% CONFIGURATIONS

% Classifier selection:
classifier = ["LDA";"QDA";"LSVM";"MLP"];
ncl = length(classifier);

% Heuristic median:
aux = dist(Xtrain).^2;
kerparx = sqrt(median(aux(:)));

% Required parameters:
sigma = kerparx;                      % bandwidth for gaussian kernel
costSVM = [0.1,0.2,0.5,1,10];         % cost parameter in LSVM
hiddensize = [2,5,10];                % size of hidden layer in MLP
comb = [0.25,0.5,0.75];               % for kernel combination in COIR
tol = 1e-2;                           % tolerance to prevent overfitting


% Recommended: Save data at this point.
save('./save')


%% RKEF-AI(COIR)
% SDR with additional information via two step method, using COIR in the
% first step and RKEF in the second step.

rng(200)

YWtrain = [Ytrain,Wtrain];
YWtest = [Ytest,Wtest];

% Reductions with d,denv and comb variables (note that we use only
% heurist median for gaussian kernel bandwidth in RKEF):
max_d = r*(r-1)/2;
d = 1:max_d;
denv = [2:3:100,120:20:300,400,500,600,700];

nd = length(d);
ndenv = length(denv);

redAItrain = cell(nd,ndenv,length(sigma),length(comb));
redAItest = redAItrain;

total = 0;
for d2 = 1:nd
    total = total+sum(denv>d(d2));
end

count = 1;
% Long-running computation, expect significant delay
for d2 = 1:nd
    for d1 = 1:ndenv
        if denv(d1)<=d(d2)
            continue
        end
        for s = 1:length(sigma)
            for c = 1:length(comb)
                try
                    [redAItrain{d2,d1,s,c},redAItest{d2,d1,s,c}] = ...
                        sdrAI(Xtrain,Wtrain,Ytrain,Xtest,d(d2),denv(d1),sigma(s),'cont',comb(c));
                catch ex
                    errorMessage = ['Error: An error occurred while applying one of the methods. Details: ', ex.message];
                    disp(errorMessage);
                end
                %
                fprintf('Reduction completed %d/%d \n',count,total)
                count = count+1;
            end
        end
    end
end


% Recommended: Save data at this point.
save('./save_AI','redAItest','redAItrain')


% Cross-validation errors for each classifier:
rng(200)
[errorsAI] = redAIerrors(redAItrain,redAItest,Ytrain,Ytest,...
    d,denv,sigma,comb,classifiers,10,tol,costSVM,hiddensize);


% Sorted errors:
sorted_errors_AI = cell(1,ncl);
for j = 1:ncl
    aux = errorsAI{1,j};
    sorted_errors_AI{1,j} = sortrows(aux,3);
end


% Final save AI:
save('./save_AI','errorsAI','sorted_errors_AI',"-append")


%% RKEF
% SDR kernel-based method (Ibanez et al 2022) without additional
% information.

rng(200)

% Reductions with d variable (note that we use only heuristic median for
% gaussian kernel bandwidth):
max_d = r*(r-1)/2;
d = 1:max_d;

nd = length(d);

redRKEFtrain = cell(nd,length(sigma));
redRKEFtest = redRKEFtrain;

for d2 = 1:nd
    for s = 1:length(sigma)
        [redRKEFtrain{d2,s},redRKEFtest{d2,s}] = RKEF(Xtrain,Ytrain,d(d2),sigma(s),Xtest);
        %
        fprintf('Reduction completed %d/%d \n',length(sigma)*(d2-1)+s,nd*length(sigma))
    end
end


% Recommended: Save data at this point.
save('./save_RKEF','redRKEFtest','redRKEFtrain')


% Cross-validation errors for each classifier:
rng(200)
[errorsRKEF] = redRKEFerrors(redRKEFtrain,redRKEFtest,Ytrain,Ytest,...
    d,sigma,classifier,10,tol,costSVM,hiddensize);


% Sorted errors:
sorted_errors_RKEF = cell(1,ncl);
for j = 1:ncl
    aux = errorsRKEF{1,j};
    sorted_errors_RKEF{1,j} = sortrows(aux,2);
end


% Final save RKEF:
save('./save_RKEF','errorsRKEF','sorted_errors_RKEF',"-append")
