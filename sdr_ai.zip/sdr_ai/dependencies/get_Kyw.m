function [Kyw] = get_Kyw(Y,W,Ytype,Wtype,c)

if nargin == 4
    c = 0.5;
end

if nargin == 2
    Ytype = 'disc';
    Wtype = 'disc';
end


if strcmp(Ytype,'disc') 
    if strcmp(Wtype,'disc')
        YW = (Y-1)*max(W)+W;
        Kyw = deltakernel(YW,YW);
    else
        aux1 = dist(W).^2;
        kerparw = sqrt(median(aux1(:)));
        Kyw = c*deltakernel(Y,Y)+(1-c)*kernel2('rbf',kerparw,W,W);
    end
end

if strcmp(Ytype,'cont') 
    if strcmp(Wtype,'cont')
        YW = [Y,W];
        Kyw = kernel('rbf',kerparyw,YW,YW);
    else
        aux1 = dist(W);
        kerparw = median(aux1(:));
        Kyw = c*deltakernel(Y)+(1-c)*kernel('rbf',kerparw,W,W);
    end
end

end