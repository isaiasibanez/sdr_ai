function [error,min_error,param_opt] = ...
    param_sel_AI(method,Kfold_int,redAItrain,Ytrain,scaleKEF,comb,tol,parameter)
% Internal cross validation for parameter selection in classifiers applied
% over a reduced train data via RKEF-AI(COIR).

%   Inputs:
%       - method: LDA, QDA, LSVM or MLP.
%       - Kfold_int: for internal cross-validation.
%       - redAItrain, Ytrain: training partition to evaluate.
%       - scaleKEF: bandwith for gaussian kernel in RKEF method ('auto' by
%       default)
%       - comb: weight/s for obtaining kernel matrix Kyw in COIR.
%       - tol: tolerance to prevent overfitting.
%       - parameter: cost for LSVM or number of neurons in hidden layer
%       for MLP.
%         
%   Outputs: errors, minimal error and parameter optimal.


if Kfold_int == 0
    partforcv = cvpartition(Ytrain,'Leaveout');
    Kfold_int = length(Ytrain);
else
    partforcv = cvpartition(Ytrain,'Kfold',Kfold_int);
end

switch method
    case {'LDA','QDA'}
        error = zeros(Kfold_int,length(scaleKEF),length(comb));        
        for s = 1:length(scaleKEF)
            for m = 1:length(comb)
                redtrain = redAItrain{1,1,s,m};
                for kaux = 1:Kfold_int
                    tr = training(partforcv,kaux);
                    te = test(partforcv,kaux);
                    if strcmp(method,'LDA')
                        modelo = fitcdiscr(redtrain(tr,:),Ytrain(tr));
                    else
                        try
                            modelo = fitcdiscr(redtrain(tr,:),Ytrain(tr),...
                                'DiscrimType','quadratic');
                        catch
                            modelo = fitcdiscr(redtrain(tr,:),Ytrain(tr),...
                                'DiscrimType','pseudoquadratic');
                        end
                    end
                Yfit = predict(modelo,redtrain(te,:));
                error(kaux,s,m) = mean(Yfit~=Ytrain(te));
                end
            end
        end    
        aux = mean(error);
        min_error = min(aux(aux>=tol));
        if isempty(min_error)
            min_error = min(aux(aux>=tol/2));
            if isempty(min_error)
                min_error = min(aux(:));
            end
        end
        [a1,a2] = ind2sub([length(scaleKEF),length(comb)],find(aux==min_error));
        param_opt = [a1(1),a2(1)];
        
    
    case 'LSVM'
        error = zeros(Kfold_int,length(scaleKEF),length(comb),length(parameter));        
        for s = 1:length(scaleKEF)
            for m = 1:length(comb)
                redtrain = redAItrain{1,1,s,m};
                for c = 1:length(parameter)
                    for kaux = 1:Kfold_int
                        tr = training(partforcv,kaux);
                        te = test(partforcv,kaux);
                        t = templateSVM('Standardize',true,'KernelFunction','linear',...
                    'BoxConstraint',parameter(c));
                        modelo = fitcecoc(redtrain(tr,:),Ytrain(tr),'Learners',t,'Verbose',0);
                        Yfit = predict(modelo,redtrain(te,:));
                        error(kaux,s,m,c) = mean(Yfit~=Ytrain(te));
                    end
                end
            end
        end
        aux = mean(error);
        min_error = min(aux(aux>=tol));
        if isempty(min_error)
            min_error = min(aux(aux>=tol/2));
            if isempty(min_error)
                min_error = min(aux(:));
            end
        end
        [a1,a2,a3] = ind2sub([length(scaleKEF),length(comb),length(parameter)],find(aux==min_error));
        param_opt = [a1(1),a2(1),a3(1)];
        
        
    case 'MLP'
        error = zeros(Kfold_int,length(scaleKEF),length(comb),length(parameter));        
        Ytrainnew = zeros(length(Ytrain),length(parameter));
        for i=1:length(Ytrain)
            class = Ytrain(i);
            Ytrainnew(i,class) = 1;
        end
        for s = 1:length(scaleKEF)
            for m = 1:length(comb)
                redtrain = redAItrain{1,1,s,m};
                for h = 1:length(parameter)
                    for kaux = 1:Kfold_int
                        tr = training(partforcv,kaux);
                        te = test(partforcv,kaux);
                        modeloMLP = patternnet(parameter(h));
                        modeloMLP.trainParam.showWindow = 0;
                        modeloMLP = train(modeloMLP,redtrain(tr,:)',Ytrainnew(tr,:)');
                        Yfit = modeloMLP(redtrain(te,:)');
                        Yfit = vec2ind(Yfit);
                        error(kaux,s,m,h) = mean(Yfit~=Ytrain(te)');
                    end
                end
            end
        end
        aux = mean(error);
        min_error = min(aux(aux>=tol));
        if isempty(min_error)
            min_error = min(aux(aux>=tol/2));
            if isempty(min_error)
                min_error = min(aux(:));
            end
        end
        [a1,a2,a3] = ind2sub([length(scaleKEF),length(comb),length(parameter)],find(aux==min_error));
        param_opt = [a1(1),a2(1),a3(1)];
end
end
