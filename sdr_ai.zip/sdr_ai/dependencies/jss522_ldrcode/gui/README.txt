################################################################################

LDR: a software package for likelihood based sufficient dimension reduction
        
                by R.D. Cook, L. Forzani and D. Tomassi
                            
                               2009
                
################################################################################

CONTENTS:
--------------------------------------------------------------------------------
This folder contains functions to run a simple graphical user interface (GUI) for 
the LDR package.
 - demo.fig: this is the figure with the uicontrols, created using the GUIDE tool
 from MATLAB.
 - demo.m: this one implements callback procedures for the uicontrols in the GUI. 
 - loadDATA4gui.m: this is another procedure to read data for the GUI.
 
 TYPE demo AT THE COMMAND WINDOW TO OPEN THE GUI.
