function [K]=kernel2(ker, param, X1, X2)
[n1,nent]=size(X1);
[n2,nent]=size(X2);

switch lower(ker)
    case 'poly',    K = (X1*X2' + 1).^param;
    case 'rbf',
                    if nent==1;
                        MX1 = (X1'.*X1')';
                        MX2 = (X2'.*X2')';
                        K = MX1*ones(1,n2) + ones(n1,1)*MX2' - 2*X1*X2';
                        K = exp((-K)/(param*param)); 
                    else            
                        MX1 = sum(X1'.*X1')';
                        MX2 = sum(X2'.*X2')';
                        K = MX1*ones(1,n2) + ones(n1,1)*MX2' - 2*X1*X2';
                        K = exp((-K)/(param*param)); 
                    end;    
    case 'idem',
        for i=1:size(X1,1),
            for j=1:size(X2,1)
                K(i,j) = X1(i,:)*X2(j,:)';
            end
        end
end